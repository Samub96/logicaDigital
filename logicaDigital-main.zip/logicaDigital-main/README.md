# logicaDigital
Es un repo para trabajar en xilins (logica digital )
